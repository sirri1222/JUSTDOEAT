const requests = {
  fetchDetail: "/store/info",
  fetchAbout: "/menu/list",
  fetchReview: "/review",
  fetchLogin: "member/list",
  
};
export default requests;