import React from 'react'

const ListMain = () => {
  return (
    <div>ListMain</div>
  )
}

export default ListMain