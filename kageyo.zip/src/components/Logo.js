import React from 'react'

const Logo = () => {
  return (
    <div>
        <img className='relative scale-50' src="/photo/jdelogo-s.png" alt="로고"></img>
    </div>
  )
}

export default Logo