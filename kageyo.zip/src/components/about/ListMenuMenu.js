import ListMenuItem from "./ListMenuItem";

const ListMenuMenu = (props) => {
  return <ListMenuItem item={props.item} />;
};

export default ListMenuMenu;
