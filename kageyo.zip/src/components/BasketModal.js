import React from 'react'

const BasketModal = () => {
  return (
    <div>BasketModal</div>
  )
}

export default BasketModal