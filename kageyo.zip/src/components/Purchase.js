import React from 'react'


const Purchase = () => {
  return (
   <div>

    
   </div>
  )
}

export default Purchase