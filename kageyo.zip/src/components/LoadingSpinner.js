import React from 'react'

const LoadingSpinner = () => {
  return (
    <div>LoadingSpinner</div>
  )
}

export default LoadingSpinner