import React from 'react'

const Layout = () => {
  return (
    <div className="max-w-6xl mx-auto h-[100vh] overflow-scroll "> 
    {/* 내용 */}
    </div>
  )
}

export default Layout