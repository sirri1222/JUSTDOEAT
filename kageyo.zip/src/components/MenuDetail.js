import React from 'react'

const MenuDetail = () => {
  return (
    <div>MenuDetail</div>
  )
}

export default MenuDetail