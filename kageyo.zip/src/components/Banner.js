import React from "react";

const Banner = () => {
  return (
    <div>
    
    </div>
  );
};

export default Banner;
