import React from "react";
import Payment from "../components/Payment";
import Layout from "../components/layout/Layout";
const Buy = () => {
  return (
   
    <div>
    <Payment/>
    </div>
  );
};

export default Buy;
