import React from "react";
import Payment from "../components/Payment";
import Layout from "../components/layout/Layout";
const Buy = () => {
  return (
    <Layout>
      <div>
        <Payment />
      </div>
    </Layout>
  );
};

export default Buy;
