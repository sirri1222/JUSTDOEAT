import React from "react";
import Payment from "../components/Payment";

const Buy = () => {
  return (
    <div>
    <Payment/>
    </div>
  );
};

export default Buy;
