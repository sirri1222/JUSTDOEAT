import React from "react";

import ShoppingBasket from "../components/cart/ShoppingBasket";
import Layout from "../components/layout/Layout";

const ShoppingBag = () => {
  return (
   
    <div>
      <ShoppingBasket />
    </div>
  );
};

export default ShoppingBag;
