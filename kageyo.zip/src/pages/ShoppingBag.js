import React from "react";

import ShoppingBasket from "../components/cart/ShoppingBasket";

const ShoppingBag = () => {
  return (
    <div>
      <ShoppingBasket />
    </div>
  );
};

export default ShoppingBag;
