# 📚 JUST DO EAT 팀 프로젝트

This project was bootstrapped with [제작 사이트](https://github.com/sirri1222/kyobo).

## 프로젝트 목적

React 미니 프로젝트

## 프로젝트 진행 상황

Notion 을 통한 일정관리

[노션사이트](https://)

## 피그마 URL

웹 서비스 레이아웃 및 컴포넌트 구조

[피그마보기](https://www.figma.com/file/NfuFBO6sBleHWZIFMDw0st/Untitled?node-id=37%3A52&t=XFFFn8t3PgdF9oGx-1) 

## 팀원구성

**`Frontend`**

**팀장 :** 손현지`<br>`
**팀원 :** 김주영 하경미

**`Backend`**

**팀장 :** `<br>`
**팀원 :** 
